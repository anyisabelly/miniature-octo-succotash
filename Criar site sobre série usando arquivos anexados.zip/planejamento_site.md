# Planejamento - Site com Tema de Séries

## Conceito Geral
Adaptar o site existente sobre Tropicália para um site dedicado a séries de TV, mantendo a estrutura visual e layout, mas alterando todo o conteúdo.

## Estrutura das Seções

### 1. Header/Navegação
- Logo: "SeriesFlix" ou "StreamZone"
- Menu: Início, Séries, Galeria, Contato

### 2. Seção Hero (Início)
- Título principal: "Bem-vindos ao mundo das séries"
- Subtítulo com logo do site
- Botão CTA: "Explorar séries"
- Background: Imagem cinematográfica/streaming

### 3. Seção Principal (Sobre)
- Título: "Por que amamos séries?"
- Texto sobre a importância das séries na cultura atual
- Foco em storytelling, personagens e entretenimento

### 4. Galeria
- Imagens de séries populares
- Cards com pôsteres de séries famosas
- Layout responsivo mantido

### 5. Contato
- Formulário para sugestões de séries
- Newsletter para novidades
- Mesmo layout visual

## Paleta de Cores
- Manter laranja como cor principal (#FF862A)
- Adicionar tons mais escuros para tema cinematográfico
- Backgrounds escuros para contraste

## Séries a Destacar
- Stranger Things
- Breaking Bad
- Game of Thrones
- The Office
- Friends
- La Casa de Papel

## Assets Necessários
- Logo personalizado para o site
- Imagens de séries populares
- Background cinematográfico
- Ícones relacionados a streaming

