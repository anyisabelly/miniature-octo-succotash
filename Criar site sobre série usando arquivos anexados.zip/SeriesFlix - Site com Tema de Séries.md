# SeriesFlix - Site com Tema de Séries

## Descrição
Site moderno e responsivo dedicado ao mundo das séries de televisão, desenvolvido com base na estrutura fornecida e adaptado para o tema de entretenimento audiovisual.

## Características Principais

### Design e Visual
- **Tema Cinematográfico**: Paleta de cores inspirada no Netflix (vermelho #E50914 e tons escuros)
- **Tipografia Elegante**: Combinação de Montserrat e Cinzel para um visual moderno e cinematográfico
- **Layout Responsivo**: Adaptável para desktop, tablet e mobile
- **Animações Suaves**: Efeitos de hover, transições e animações de entrada

### Seções do Site

#### 1. Header/Navegação
- Logo "SeriesFlix" com design elegante
- Menu de navegação com efeitos hover
- Navegação suave entre seções

#### 2. Seção Hero (Início)
- Background cinematográfico com overlay
- Título principal com efeito de gradiente
- Botão call-to-action com animações
- Design imersivo e impactante

#### 3. Seção "Por que amamos séries?"
- Conteúdo informativo sobre a importância das séries
- Estatísticas animadas (contadores)
- Cards com informações relevantes
- Layout em duas colunas responsivo

#### 4. Galeria de Séries
- Showcase de séries populares com imagens reais
- Cards interativos com overlay de informações
- Sistema de avaliação com estrelas
- Tags de gêneros populares
- Efeitos hover sofisticados

#### 5. Formulário de Contato
- Formulário completo com validação JavaScript
- Campo específico para "Série Favorita"
- Design moderno com backdrop blur
- Validação de email e campos obrigatórios
- Feedback visual para o usuário

#### 6. Footer
- Links para redes sociais com ícones animados
- Design consistente com o tema
- Informações de copyright

### Funcionalidades JavaScript

#### Interatividade
- Scroll suave entre seções
- Animações de entrada baseadas em viewport
- Contadores animados para estatísticas
- Efeito de digitação no título principal
- Validação completa do formulário

#### Efeitos Visuais
- Parallax suave no header
- Hover effects nos cards
- Transições suaves em todos os elementos
- Animações de fade-in progressivas

### Tecnologias Utilizadas
- **HTML5**: Estrutura semântica e acessível
- **CSS3**: Flexbox, Grid, animações e gradientes
- **JavaScript ES6**: Interatividade e validações
- **Bootstrap 5**: Sistema de grid responsivo
- **Bootstrap Icons**: Ícones modernos e consistentes
- **Google Fonts**: Tipografia profissional

### Arquivos do Projeto
```
series_site/
├── index.html          # Página principal
├── styles.css          # Estilos personalizados
├── script.js           # Funcionalidades JavaScript
├── img/                # Diretório de imagens
│   ├── cinema_background.jpg
│   ├── series_posters.jpg
│   ├── stranger_things.jpg
│   └── tv_posters.jpg
└── README.md           # Documentação
```

### Responsividade
- **Desktop**: Layout completo com todas as funcionalidades
- **Tablet**: Adaptação do grid e redimensionamento de elementos
- **Mobile**: Layout otimizado para telas pequenas com navegação touch-friendly

### Paleta de Cores
- **Vermelho Principal**: #E50914 (Netflix Red)
- **Laranja Secundário**: #FF6B35 (Cinematográfico)
- **Preto Escuro**: #141414 (Netflix Black)
- **Cinza**: #333333
- **Dourado**: #FFD700 (Avaliações)
- **Claro**: #F5F5F5

### Como Usar
1. Abra o arquivo `index.html` em qualquer navegador moderno
2. Navegue pelas seções usando o menu ou scroll
3. Interaja com os elementos para ver as animações
4. Teste o formulário de contato
5. Experimente em diferentes tamanhos de tela

### Compatibilidade
- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+
- Dispositivos móveis iOS e Android

## Créditos
Desenvolvido com base na estrutura original fornecida, adaptado para o tema de séries com design moderno e funcionalidades avançadas.

